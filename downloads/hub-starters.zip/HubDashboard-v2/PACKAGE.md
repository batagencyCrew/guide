# HUB v2 integration package

Production HUB_URL=https://bamboubot.duckdns.org
Start at https://bambou-onboarding.pages.dev/hub.html

Contains all 9 Hub v2 Markdown documents, the v2 VPS agent (agent2/),
Python and Node.js SDKs (sdk/python, sdk/node), Python and Node.js script
starters (templates/v2/python, templates/v2/node), and the systemd unit
(deploy/bambou-agent@.service).

Install one bambou-agent per VPS/site token. Your automation script imports
bambouhub from sdk/ and talks to bambou-agent over a local Unix socket; the
script never holds HUB_AGENT_TOKEN. Replace placeholder tokens privately; no
production credentials or runtime data are included.

The hub backend/frontend application implementation is not included. Deployment
and frontend READMEs are operator reference only; connect your automation to
the hosted HUB instead of deploying your own HUB.

Only placeholder production domains have been updated in copied sources.
Local development examples retain their explicit local meanings.
Source commit: 5b4d09f485214d2fc3f74e57809a17f6e991acbd (working-tree snapshot)
